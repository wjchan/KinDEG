KinDEG_v0.1 by Wei Jian Chan

To run, the installation of the following is required:
Processing 1.5.1
OpenNI
OpenCV

Processing Libraries:
JavaCVPro 0.4 Beta
Simple OpenNI v2.7

1. Run main_processing_v3.pde and press any key to quit.
2. log.txt generated should be placed in graphGen folder.
3. Run graphGen.pde to display the result. 
4. Char 'choice' in graphGen.pde can be changed to display various results.